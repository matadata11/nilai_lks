<?php defined('BASEPATH') OR exit('No direct script access allowed');

$config['version']      = '0.0.2 Rilis';
$config['Aauthor']      = 'Not Found dot ID';
$config['sistem']       = 'https://notfound.id';
$config['email']        = 'matadata.dev2021@gmail.com';
$config['dev']          = 'Bidang Pembinaan SMK Aceh';
