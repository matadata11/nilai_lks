<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class M_penilaian extends CI_Model {

	

}

/* End of file M_penilaian.php */
