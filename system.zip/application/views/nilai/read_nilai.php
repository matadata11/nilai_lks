<section class="section">
    <div class="section-header">
        <h1>Master Peserta LKS</h1>
        <div class="ml-auto">
            <a href="#add" data-toggle="modal" class="btn btn-sm btn-primary"><i class="fas fa-fw fa-plus"></i> Tambah</a>
            <a href="#import" data-toggle="modal" class="btn btn-sm btn-primary"><i class="fas fa-fw fa-file-import"></i> Import</a>
        </div>
    </div>

</section>

<?php require_once('modals/_peserta.php'); ?>
