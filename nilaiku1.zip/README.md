# nilai_lks
